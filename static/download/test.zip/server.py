from flask import Flask, send_from_directory, redirect
import os
app = Flask(__name__, static_folder='static')

@app.route(/)
@app.route('/home')
def welcome():
    return send_from_directory(os.path.join(app.static_folder, 'html'), "index.html")


@app.route('/<path:js_name>')
def serve_testJs(js_name):
    return send_from_directory(os.path.join(app.static_folder, 'js'), js_name)


app.run('0.0.0.0')